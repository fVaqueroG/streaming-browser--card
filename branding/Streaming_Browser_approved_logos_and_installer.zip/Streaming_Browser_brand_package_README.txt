Streaming Browser — supplied logos (original, full-resolution transparent PNGs)

The Streaming Browser launcher sizing update is already published as v0.4.126.
This package contains the three EXACT user-uploaded PNGs plus a local helper
for replacing the existing repo assets with these newer logos. The PNGs were
not uploaded to GitHub in the v0.4.126 update.

From a local clone of https://github.com/fVaqueroG/streaming-browser--card :
  python3 /path/to/extracted/apply_streaming_browser_logos.py /path/to/your/streaming-browser--card
  node --check custom_components/streaming_browser/frontend/streaming-browser-popup-card.js
  node --check custom_components/streaming_browser/frontend/streaming-browser-card-v2.js
  git add custom_components/streaming_browser/frontend custom_components/streaming_browser/manifest.json
  git commit -m 'v0.4.127: use supplied transparent Streaming Browser logos'
  git push
  gh release create v0.4.127 --target main --title v0.4.127 --notes 'Use user-approved transparent icon, vertical and horizontal Streaming Browser logos.'

Requires a clone currently at 0.4.126. The helper checks for mismatched versions.
Do not upload your Home Assistant YAML or TMDB key to the public repository.
