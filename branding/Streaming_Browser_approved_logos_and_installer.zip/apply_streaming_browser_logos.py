#!/usr/bin/env python3
"""Apply the three user-approved 2026-09-22 PNGs to a Streaming Browser repo clone."""
import argparse
import json
import shutil
from pathlib import Path

ASSETS = ('icon', 'vertical', 'horizontal')
OLD = '0.4.126'
NEW = '0.4.127'


def apply(repo: Path, package: Path) -> None:
    root = repo / 'custom_components' / 'streaming_browser'
    manifest = root / 'manifest.json'
    popup = root / 'frontend' / 'streaming-browser-popup-card.js'
    v2 = root / 'frontend' / 'streaming-browser-card-v2.js'
    asset_dir = root / 'frontend' / 'assets'
    for path in (manifest, popup, v2):
        if not path.is_file():
            raise FileNotFoundError(f'Not a Streaming Browser repository: {path}')
    data = json.loads(manifest.read_text(encoding='utf-8'))
    if data.get('version') != OLD:
        raise RuntimeError(f'Expected version {OLD}, found {data.get("version")}; inspect recent repository changes before applying.')
    sources = {kind: package / f'Streaming Browser Logo {kind.title()}.png' for kind in ASSETS}
    sources['vertical'] = package / 'Streaming Browser Logo Vertical(1).png'
    sources['horizontal'] = package / 'Streaming Browser Logo Horizontal(1).png'
    for kind, path in sources.items():
        if not path.is_file() or path.read_bytes()[:8] != b'\x89PNG\r\n\x1a\n':
            raise RuntimeError(f'Missing valid original PNG for {kind}: {path}')
    for kind, path in sources.items():
        shutil.copyfile(path, asset_dir / f'streaming-browser-{kind}-v127.png')
        shutil.copyfile(path, asset_dir / f'streaming-browser-{kind}.png')
    for path in (popup, v2):
        content = path.read_text(encoding='utf-8')
        for kind in ASSETS:
            content = content.replace(f'streaming-browser-{kind}-v124.png', f'streaming-browser-{kind}-v127.png')
        content = content.replace('?v=0.4.125', '?v=0.4.127').replace('?v=0.4.126', '?v=0.4.127')
        if path == v2:
            old = 'const STREAMING_BROWSER_VERSION = "0.4.126";'
            if content.count(old) != 1:
                raise RuntimeError('V2 version string did not match; no commit was made.')
            content = content.replace(old, 'const STREAMING_BROWSER_VERSION = "0.4.127";')
        path.write_text(content, encoding='utf-8')
    data['version'] = NEW
    manifest.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    print(f'Updated {root}: three original PNGs copied; popup/V2 references and manifest bumped to {NEW}.')
    print('Changes are local to this repository clone; review, commit, push and publish a v0.4.127 release.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', nargs='?', default='.', type=Path, help='Local clone of fVaqueroG/streaming-browser--card')
    args = parser.parse_args()
    apply(args.repo.resolve(), Path(__file__).resolve().parent)
